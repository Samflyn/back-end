package com.test.two;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Sixth {
	public static void main(String[] args) throws IOException {
		File f = null;
		FileInputStream fis = null;
		DataInputStream dis = null;
		StringBuffer distinct = new StringBuffer();
		try {
			f = new File(args[0]);
			fis = new FileInputStream(f);
			dis = new DataInputStream(fis);
			String line = dis.readLine();
			while (line != null && !line.isEmpty()) {
				distinct.append(line);
				distinct.append(" ");
				line = dis.readLine();
			}
			String all = distinct.toString();
			String[] split = all.split(" ");
			for (int i = 0; i < split.length; i++) {
				System.out.println(split[i]);
			}
			dis.close();
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (dis != null) {
				dis.close();
			}
			if (fis != null) {
				fis.close();
			}
		}
	}
}
