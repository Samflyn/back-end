package com.test.two;

import java.util.Arrays;

public class Nineth {
	public static void main(String[] args) {
		int[] i = { 5, 34, 78, 2, 45, 1, 99, 23 };
		Arrays.sort(i, 0, i.length);
		System.out.println("Two maximum numbers are : "+i[i.length-1]+","+i[i.length-2]);
	}
}
