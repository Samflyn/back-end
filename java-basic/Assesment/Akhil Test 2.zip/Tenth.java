package com.test.two;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Tenth {
	public static void main(String[] args) throws IOException {
		File f = null;
		FileInputStream fis = null;
		DataInputStream dis = null;
		StringBuffer sb = new StringBuffer();
		ArrayList<String> al = new ArrayList<String>();
		try {
			f = new File(args[0]);
			if (!f.isFile()) {
				System.out.println("Given directory is not a file");
				System.exit(0);
			}
			if (!f.exists()) {
				System.out.println("File already exists");
				System.exit(0);
			}
			if (!f.canWrite()) {
				System.out.println("Write permission denied");
				System.exit(0);
			}
			fis = new FileInputStream(f);
			dis = new DataInputStream(fis);
			String line = dis.readLine();
			while (line != null && !line.isEmpty()) {
				sb.append(line);
				sb.append(" ");
				line = dis.readLine();
			}
			al.add(sb.toString());
			String ss = sb.toString();
			String[] split = ss.split(" ");
			int count = 0;
			ArrayList<Integer> al1 = new ArrayList<Integer>();
			for (int i = 0; i < split.length; i++) {
				for (int j = i; j < split.length; j++) {
					if (split[i].contains(split[j])) {
						count++;
					}
				}
				al1.add(i, count);
				count = 0;
			}
			int large = 0;
			for (int i = 0; i < al1.size(); i++) {
				for (int j = 0; j < al1.size(); j++) {
					if (al1.get(0) > al1.get(j)) {
						large = 0;
					} else {
						large = j;
					}
				}
			}
			System.out.println("Maximum repeated word is : " + split[large]);
			dis.close();
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (dis != null) {
				dis.close();
			}
			if (fis != null) {
				fis.close();
			}
		}

	}
}
