package com.test.two;

public class Fifth {
	public static void main(String[] args) {
		String s = "abcdaeeddc";
		char[] ch = s.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < ch.length; i++) {
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					sb.append(ch[i]);
					break;
				}
			}
		}
		StringBuffer ss = new StringBuffer();
		for (int i = 0; i < sb.length(); i++) {
			for (int j = 0; j < ch.length; j++) {
				if (!(sb.charAt(0) == ch[j])) {
					ss.append(ch[j]);
					break;
				}
			}
		}
		System.out.println("First Repeated word : " + sb.charAt(0));
		System.out.println("First non repeating word : " + ss.charAt(0));
	}
}
