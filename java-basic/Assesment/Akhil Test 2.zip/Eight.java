package com.test.two;

public class Eight {
	static int num;

	public static void main(String[] args) {
		int i = 123;
		adding(i);
		System.out.println(num);
	}

	public static void adding(int j) {
		if (j != 0) {
			int i = j % 10;
			num = num + i;
			j = j / 10;
			adding(j);
		}

	}
}
