package testcom.test;

public class FourtyFour {
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		Swap s = new Swap();
		s.setI(i);
		s.setJ(j);
		j = s.getI();
		i = s.getJ();
		System.out.println("i : " + i);
		System.out.println("j : " + j);
	}
}
