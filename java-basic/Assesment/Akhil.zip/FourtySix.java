package testcom.test;

import java.util.Scanner;

public class FourtySix {
	public static void main(String[] args) {
		System.out.println("Enter a string");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String s1 = str.substring(0, str.length() / 2);
		String s2 = str.substring(str.length() / 2, str.length());
		StringBuffer sb = new StringBuffer();
		for (int i = s2.length() - 1; i >= 0; i--) {
			sb.append(s2.charAt(i));
		}
		String st = sb.toString();
		if (s1.equals(st)) {
			System.out.println("Palindrom");
		} else {
			System.out.println("not palindrom");
		}
		sc.close();
	}
}
