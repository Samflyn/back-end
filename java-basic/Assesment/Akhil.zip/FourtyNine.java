package testcom.test;

public class FourtyNine {
	public static void main(String[] args) {
		String[] str = null;
		try {
			System.out.println(str);
			if (str == null) {
				throw new NullPointerException("String is null");
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
