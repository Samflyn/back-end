package com.test.three;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;

import com.test.three.ExcelGenerator;

public class Sixth {
	public static void main(String[] args) {
		File file = null;
		FileInputStream fis = null;
		DataInputStream dis = null;
		StringBuffer sb = null;
		File dst = null;
		ArrayList<String> al = new ArrayList<String>();
		try {
			file = new File(args[0]);
			if (!file.isFile()) {
				System.out.println("Given directory is not a file");
				System.exit(0);
			}
			String root=file.getParent()+file.pathSeparator+"Excel";
			dst=new File(root);
			fis = new FileInputStream(file);
			dis = new DataInputStream(fis);
			String record = dis.readLine();
			while (record != null && !record.isEmpty()) {
				al.add(record);
				record = dis.readLine();
			}
			Iterator<String> iterator = al.iterator();
			while (iterator.hasNext()) {
				sb.append(iterator.next());
			}
			String[] records = sb.toString().split(":");
			ExcelGenerator excel = new ExcelGenerator();
			excel.gen(records,dst);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
